try:
    num1 = int(input("Введите первое число: "))
    num2 = int(input("Введите второе число: "))
    result = num1 / num2
    print("Результат деления:",result)
except ValueError:
    print("Нужно ввести два целых числа")
except ZeroDivisionError:
    print("На ноль делить нельзя")