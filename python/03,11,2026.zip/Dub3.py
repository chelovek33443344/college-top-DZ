continue_loop = True
while continue_loop:
    a = int(input("Введите число"))
    if a > 0:
        print("Number is positive")
    elif a < 0:
        print("Number is negative")
    elif a == 0:
        print("Number is equal to zero")
    elif a == 7:
        print("Goodbye")
        continue_loop = False
    else:
        print("Что то не так")

