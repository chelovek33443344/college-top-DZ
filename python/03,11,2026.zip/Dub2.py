a = int(input("Длинну строки "))

for i in range(0, a):
    print("%") 